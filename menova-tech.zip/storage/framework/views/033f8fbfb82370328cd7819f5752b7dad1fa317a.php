
<?php $__env->startSection('title'); ?>
Venice Decor | <?php echo e($service->name); ?> Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>
    // var el=$( 'a[href="#services"]' );
    // $(el).addClass('active');
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="main_site">
    <div class="top_section d-flex align-items-center">
      <div class="container">
        <h1 class="text-uppercase text-center page_title text_bold margin_top_4"><?php echo e($service->name); ?></h1>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Services</li>
          </ol>
        </nav>
      </div>
    </div>
    <section class="blog_page">
      <div class="container">
        <div class="row text-left">
          <div class="col-md-12 col-lg-8 left-side">
            <div class="article">
              <div class="article_img br_radius text-center d-flex align-items-center">
                <img class="w-100 br_radius margin_bottom" src="/front/img/portfolio1.jpg" alt="article image">
              </div>
              <h3 class="article-tit text-capitalize"><?php echo e($service->name); ?></h3>
              <div class="article_content margin_top">
                <?php echo $service->content; ?>

                
                <div class="social d-flex align-items-center">
                  <h3 class="text-uppercase margin_right">share on : </h3>
                  <span><a class="facebook" href="#"><i class="fab fa-facebook-f"></i></a></span>
                  <span><a class="twitter" href="#"><i class="fab fa-twitter"></i></a></span>
                  <span><a class="google" href="#"><i class="fab fa-google-plus-g"></i></a></span>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <aside class="aside-sec">
              <div class="categories margin_bottom">
                <h3 class="text-uppercase aside_tit margin_bottom">Our Servises</h3>
                <ul>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $srv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="cat_item"><a href="<?php echo e(asset('service/'.$srv->id)); ?>"><?php echo e($srv->name); ?> <i class="fas fa-chevron-right float-right col_purple"></i></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\projects\menova-tech\menova-tech\resources\views/front/service.blade.php ENDPATH**/ ?>