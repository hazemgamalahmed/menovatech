<!DOCTYPE html>

<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
    <!-- Favicons -->
    <link rel="icon" href="myicon.ico" sizes="16x16" type="image/png">
    <!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href="/front/css/inc/plugins.css">
    <!-- CSS Global Compulsory -->
    <link rel="stylesheet" href="/front/css/style.css">
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    
    <?php echo $__env->make('front.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- main content -->
    
    <?php echo $__env->yieldContent('content'); ?>
    
    <footer class="site_footer text-center bg_blue_grad text-white">
        <div class="container">
            <p>ZAGENCY © 2016 All Rights Reserved.</p>
        </div>
    </footer>
    <script src="/front/js/jQuery-plugins.js"></script>
    <script src="/front/js/scripts.js"></script>
    
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html><?php /**PATH F:\projects\menova-tech\menova-tech\resources\views/front/layouts/app.blade.php ENDPATH**/ ?>